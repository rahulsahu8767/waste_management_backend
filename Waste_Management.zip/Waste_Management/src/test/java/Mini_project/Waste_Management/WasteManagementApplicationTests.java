package Mini_project.Waste_Management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WasteManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
